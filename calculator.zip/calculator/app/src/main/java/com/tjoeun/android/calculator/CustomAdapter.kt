package com.tjoeun.android.calculator

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*
import kotlin.collections.ArrayList

class CustomAdapter(val context:Context, val unitArray: ArrayList<String>): BaseAdapter(){

//    private val inflater:LayoutInflater = LayoutInflater.from(context)
    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    override fun getCount(): Int {
        return if(unitArray.isNotEmpty()){
            unitArray.size
        } else 0
    }

    override fun getItem(position: Int): Any {
        return unitArray[position]
    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =with(BufferedReader(InputStreamReader(System.`in`))) {
//        var view:View
//        if(convertView==null){
//            view = inflator.inflate(R.layout.spinner_background,parent,false)
//        } else {
//            view = convertView
//        }
//        return view
        val view: View
        val vh: ItemHolder
        if (convertView == null) {
            view = inflater.inflate(R.layout.spinner_background, parent, false)
            vh = ItemHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as ItemHolder
        }
        val textView = unitArray.get(position).split(" ")[0]

        vh.label.text = textView

        return view
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        val view: View
        val vh: ItemHolder
        if (convertView == null) {
            view = inflater.inflate(R.layout.spinner_background, parent, false)
            vh = ItemHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as ItemHolder
        }
        vh.label.text = unitArray.get(position)

        return view
    }
    private class ItemHolder(row: View?) {
        val label: TextView = row?.findViewById(R.id.dropdown_back) as TextView
    }
}
