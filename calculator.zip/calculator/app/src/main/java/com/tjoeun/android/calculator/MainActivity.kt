package com.tjoeun.android.calculator

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.tjoeun.android.calculator.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {
    var allStr = StringBuffer(" ")
    var isParentheses = false
    var isOperator = false
    var isNegative = false
    var finalOperatorIndex = 0
    var countParentheses = 0
    val calc = Calculator()
    val queueFormula:Queue<StringBuffer> = LinkedList()
    val queueResult:Queue<StringBuffer> = LinkedList()

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding = DataBindingUtil.setContentView(
                this, R.layout.activity_main)

        binding.button1.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x1")
            } else {
                allStr.append('1')
            }
            preview(allStr)
        }
        binding.button2.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x2")
            } else {
                allStr.append('2')
            }
            preview(allStr)
        }
        binding.button3.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x3")
            } else {
                allStr.append('3')
            }
            preview(allStr)
        }
        binding.button4.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x4")
            } else {
                allStr.append('4')
            }
            preview(allStr)
        }
        binding.button5.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x5")
            } else {
                allStr.append('5')
            }
            preview(allStr)
        }
        binding.button6.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x6")
            } else {
                allStr.append('6')
            }
            preview(allStr)
        }
        binding.button7.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x7")
            } else {
                allStr.append('7')
            }
            preview(allStr)
        }
        binding.button8.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x8")
            } else {
                allStr.append('8')
            }
            preview(allStr)
        }
        binding.button9.setOnClickListener{
            isOperator = false
            if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x9")
            } else {
                allStr.append('9')
            }
            preview(allStr)
        }
        binding.button0.setOnClickListener{
            isOperator = false
            if(allStr.last() == ' '){

            } else if(allStr.last() == '%' || allStr.last() == ')'){
                allStr.append("x0")
            } else {
                allStr.append('0')
            }
            preview(allStr)
        }

        // 연산자 버튼

        binding.buttonPlus.setOnClickListener{
            if(!isOperator){
                isOperator = true
                isNegative = false
                allStr.append('+')
                finalOperatorIndex = allStr.lastIndex
                preview(allStr)
            } else if(allStr.last() == '-' && isNegative){
                allStr.deleteCharAt(allStr.lastIndex)
            }
        }
        binding.buttonMinus.setOnClickListener{
            if(!isOperator){
                isOperator = true
                isNegative = false
                allStr.append('-')
                finalOperatorIndex = allStr.lastIndex
                preview(allStr)
            } else if(allStr.last() == '-' && isNegative){

            }
        }
        binding.buttonTimes.setOnClickListener{
            if(!isOperator){
                isOperator = true
                isNegative = false
                allStr.append('x')
                finalOperatorIndex = allStr.lastIndex
                preview(allStr)
            } else if(allStr.last() == '-' && isNegative){
                allStr.deleteCharAt(allStr.lastIndex)
            }
        }
        binding.buttonDiv.setOnClickListener{
            if(!isOperator){
                isOperator = true
                isNegative = false
                allStr.append('÷')
                finalOperatorIndex = allStr.lastIndex
                preview(allStr)
            } else if(allStr.last() == '-' && isNegative){
                allStr.deleteCharAt(allStr.lastIndex)
            }
        }
        binding.buttonPercent.setOnClickListener{
            if(!isOperator){
                isOperator = true
                isNegative = false
                allStr.append('%')
                finalOperatorIndex = allStr.lastIndex
                binding.textInput.text = allStr
            } else {
                Toast.makeText(applicationContext, "완성되지 않은 수식입니다.", Toast.LENGTH_SHORT).show()
            }
        }
        binding.buttonPar.setOnClickListener{
            if(!isParentheses && !isOperator){
                isParentheses = true
                isOperator = true
                allStr.append("x(")
                countParentheses++
            } else if((!isParentheses && isOperator) || (isParentheses && isOperator)){
                isParentheses = true
                allStr.append("(")
                countParentheses++
            } else {
                if (countParentheses>0) {
                    isParentheses = false
                    allStr.append(")")
                    countParentheses--
                }
            }
            finalOperatorIndex = allStr.lastIndex
            binding.textInput.text = allStr
        }
        binding.buttonClear.setOnClickListener{
            allStr = StringBuffer(" ")
            isParentheses = false
            isOperator = false
            isNegative = false
            preview(allStr)
        }
        binding.buttonPoint.setOnClickListener{
            if(!isOperator){
                allStr.append('.')
                binding.textInput.text = allStr
            } else if(allStr.last() == '.') {
                binding.textInput.text = allStr
            } else {
                allStr.append("0.")
                binding.textInput.text = allStr
            }
        }
        binding.buttonChange.setOnClickListener {
            if (!isNegative) {
                if (isOperator || isParentheses) {
                    isNegative = true
                    isParentheses = true
                    allStr.append("(-")
                } else if (allStr.last() == '%' || allStr.last() == ')') {
                    isNegative = true
                    allStr.append("x(-")
                } else {
                    for(i in allStr.lastIndex downTo 0){
                        if(allStr[i].toInt() !in 48..57){
                            allStr.insert(i+1, "(-")
                        }
                        break
                    }
                }
                binding.textInput.text = allStr
            }
            if (isNegative) {
                if (allStr.last() == '-') {
                    isNegative = false
                    isParentheses = false
                    allStr.delete(allStr.lastIndex-1,allStr.lastIndex)
                } else {
                    for(i in allStr.lastIndex downTo 0){
                        if(allStr[i].toInt() !in 48..57){
                            isNegative = false
                            allStr.insert(i+1, "(-")
                        }
                        break
                    }
                }
                binding.textInput.text = allStr
            }
        }
        binding.buttonRecord.setOnClickListener(){

        }
        binding.buttonTrans.setOnClickListener(){
            val intent = Intent(this,TransUnit::class.java)
            startActivity(intent)
        }
//        binding.buttonMath.setOnClickListener(){
//
//        }
        binding.buttonDelete.setOnClickListener{
            if(allStr.isNotEmpty()){
                allStr.deleteCharAt(allStr.length - 1)
                val operatorList = listOf("x","-","+","(",")","÷")
                if(allStr.isNotEmpty() && allStr.last() !in operatorList){
                    isOperator = false
                    preview(allStr)
                } else {
                    isOperator = true
                    preview(allStr)
                }
            }
        }
        binding.buttonEqual.setOnClickListener{
            val result = calc.calculate(calc.postFix(calc.makeList(allStr)))
            isOperator = false
            isParentheses = false
            binding.textInput.text = result
            binding.textCurrent.text = ""
            allStr = StringBuffer(" ")
        }
    }
    private fun preview(allStr:StringBuffer){
        val textInput = findViewById<TextView>(R.id.textInput)
        val textCurrent = findViewById<TextView>(R.id.textCurrent)
        textInput.text = allStr
        if(!isOperator) {
            textCurrent.text = calc.calculate(calc.postFix(calc.makeList(allStr)))
        } else {
            textCurrent.text = ""
        }
    }
}
