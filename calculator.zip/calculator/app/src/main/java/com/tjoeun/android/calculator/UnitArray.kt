package com.tjoeun.android.calculator

class UnitArray {
    val area = arrayListOf("에이커 (ac)","아르 (a)","헥타르 (ha)","제곱센티미터 (cm2)","제곱피트 (ft2)","제곱인치 (in2)","제곱미터 (m2)","평 (평)")
    val length = arrayListOf("밀리미터 (mm)","센티미터 (cm)","미터 (m)","킬로미터 (km)","인치 (in)","피트 (ft)","야드 (yd)","마일 (mi)",
                         "해리 (NM)","밀 (mil)","자 (자)","리 (리)")
    val temp = arrayListOf("섭씨 (℃)","화씨 (℉)","켈빈 (K)")
    val time = arrayListOf("영국갤런 (gal)","미국 런 (gal)","리터 (l)","밀리리터 (ml)","세제곱센티미터 (cm3)","세제곱미터 (m3)","세제곱인치 (in3)",
                       "세제곱피트 (ft3)","말 (말)","되 (되)")
    val data = arrayListOf("톤 (t)","영국톤 (t)","미국톤 (t)","파운드 (lb)","온스 (oz)","킬로그램 (kg)","그램 (g)","근 (근)","돈 (돈)")
    val volume = arrayListOf("비트 (bit)","바이트 (B)","킬로바이트 (KB)","메가바이트 (MB)","기가바이트 (GB)","테라바이트 (TB)")
    val speed = arrayListOf("초당 미터 (m/s)","시간당 미터 (m/h)","초당 킬로미터 (km/s)","시간당 킬로미터 (km/h)","초당 인치 (in/s)","시간당 인치 (in/h)",
                        "초당 피트 (ft/s)","시간당 피트 (ft/h)","초당 마일 (mi/s)","시간당 마일 (mi/h)","노트 (kn)")
    val weight = arrayListOf("밀리초 (ms)","초 (s)","분 (min)","시간 (h)","일 (d)","주 (wk)")
}