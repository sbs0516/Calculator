package com.tjoeun.android.calculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.databinding.DataBindingUtil
import com.tjoeun.android.calculator.databinding.ActivityTransUnitBinding

class TransUnit : AppCompatActivity() {
    var transStrFirst = StringBuffer("1")
    var transStrSecond = StringBuffer("")
    var firstOrSecond = true
    val transUnit = TransUnitFunc()
    var unitFirst = "에이커"
    var unitSecond = "에이커"
    var transMap = transUnit.areaMapBaseHa

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trans_unit)

        val bindingUnit: ActivityTransUnitBinding = DataBindingUtil.setContentView(
            this, R.layout.activity_trans_unit)
        val spinnerUp = findViewById<Spinner>(R.id.spinnerUp)
        val spinnerDown = findViewById<Spinner>(R.id.spinnerDown)
        val unit = UnitArray()

        bindingUnit.transTextInput.showSoftInputOnFocus = false
        bindingUnit.transTextInput.setTextIsSelectable(true)
        bindingUnit.transTextInput.setSelection(bindingUnit.transTextInput.text.length)
        bindingUnit.transTextInput1.showSoftInputOnFocus = false
        bindingUnit.transTextInput1.setTextIsSelectable(true)
        bindingUnit.transTextInput1.setSelection(bindingUnit.transTextInput1.text.length)

        val adapterSpinner = CustomAdapter(this, unit.area)
        spinnerUp.setSelection(0)
        spinnerDown.setSelection(0)
//        bindingUnit.transTextInput.text.append(transStrFirst)
//        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
//        bindingUnit.transTextInput1.text.append(transStrSecond)
        spinnerUp.adapter = adapterSpinner
        spinnerUp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when(position){
                    0 -> {
                        spinnerUp.setSelection(0)
                        unitFirst = "에이커"
                        bindingUnit.textInputUnit.text = "ac"
//                        bindingUnit.transTextInput.text.append(transStrFirst)
//                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
//                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    1 -> {
                        spinnerUp.setSelection(1)
                        unitFirst = "아르"
                        bindingUnit.textInputUnit.text = "a"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    2 -> {
                        spinnerUp.setSelection(2)
                        unitFirst = "헥타르"
                        bindingUnit.textInputUnit.text = "ha"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    3 -> {
                        spinnerUp.setSelection(3)
                        unitFirst = "제곱센티미터"
                        bindingUnit.textInputUnit.text = "cm2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    4 -> {
                        spinnerUp.setSelection(4)
                        unitFirst = "제곱피트"
                        bindingUnit.textInputUnit.text = "ft2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    5 -> {
                        spinnerUp.setSelection(5)
                        unitFirst = "제곱인치"
                        bindingUnit.textInputUnit.text = "in2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    6 -> {
                        spinnerUp.setSelection(6)
                        unitFirst = "제곱미터"
                        bindingUnit.textInputUnit.text = "m2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    7 -> {
                        spinnerUp.setSelection(7)
                        unitFirst = "평"
                        bindingUnit.textInputUnit.text = "평"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
        spinnerDown.adapter = adapterSpinner
        spinnerDown.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when(position){
                    0 -> {
                        spinnerDown.setSelection(0)
                        unitSecond = "에이커"
                        bindingUnit.textInputUnit1.text = "ac"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    1 -> {
                        spinnerDown.setSelection(1)
                        unitSecond = "아르"
                        bindingUnit.textInputUnit1.text = "a"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    2 -> {
                        spinnerDown.setSelection(2)
                        unitSecond = "헥타르"
                        bindingUnit.textInputUnit1.text = "ha"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    3 -> {
                        spinnerDown.setSelection(3)
                        unitSecond = "제곱센티미터"
                        bindingUnit.textInputUnit1.text = "cm2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    4 -> {
                        spinnerDown.setSelection(4)
                        unitSecond = "제곱피트"
                        bindingUnit.textInputUnit1.text = "ft2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    5 -> {
                        spinnerDown.setSelection(5)
                        unitSecond = "제곱인치"
                        bindingUnit.textInputUnit1.text = "in2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    6 -> {
                        spinnerDown.setSelection(6)
                        unitSecond = "제곱미터"
                        bindingUnit.textInputUnit1.text = "m2"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                    7 -> {
                        spinnerDown.setSelection(7)
                        unitSecond = "평"
                        bindingUnit.textInputUnit1.text = "평"
                        bindingUnit.transTextInput.text.append(transStrFirst)
                        transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                        bindingUnit.transTextInput1.text.append(transStrSecond)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        bindingUnit.button1.setOnClickListener {
            if(firstOrSecond) {
                bindingUnit.transTextInput.text.append("1")
                transStrSecond = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                bindingUnit.transTextInput1.text.append(transStrSecond)
            } else {
                bindingUnit.transTextInput1.text.append("1")
                transStrFirst = transUnit.transUnitFunc(unitFirst,unitSecond,transStrFirst,transMap,firstOrSecond)
                bindingUnit.transTextInput.text.append(transStrFirst)
            }

        }
        bindingUnit.button2.setOnClickListener {

        }
        bindingUnit.button3.setOnClickListener {

        }
        bindingUnit.button4.setOnClickListener {

        }
        bindingUnit.button5.setOnClickListener {

        }
        bindingUnit.button6.setOnClickListener {

        }
        bindingUnit.button7.setOnClickListener {

        }
        bindingUnit.button8.setOnClickListener {

        }
        bindingUnit.button9.setOnClickListener {

        }
        bindingUnit.button0.setOnClickListener {

        }
        bindingUnit.buttonChange.setOnClickListener {

        }
        bindingUnit.buttonPoint.setOnClickListener {

        }
        bindingUnit.buttonUp.setOnClickListener {

        }
        bindingUnit.buttonDown.setOnClickListener {

        }
        bindingUnit.buttonClear.setOnClickListener {

        }
        bindingUnit.buttonDelete.setOnClickListener {

        }
        bindingUnit.backToCalc.setOnClickListener{
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        bindingUnit.area.setOnClickListener{
            val adapterSpinner = CustomAdapter(this, unit.area)

            spinnerUp.setSelection(0)
            spinnerDown.setSelection(5)
            spinnerUp.adapter = adapterSpinner
            spinnerUp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    when(position){
                        0 -> {
                            spinnerUp.setSelection(0)
                            bindingUnit.textInputUnit.text = "ac"
                        }
                        1 -> {
                            spinnerUp.setSelection(1)
                            bindingUnit.textInputUnit.text = "a"
                        }
                        2 -> {
                            spinnerUp.setSelection(2)
                            bindingUnit.textInputUnit.text = "ha"
                        }
                        3 -> {
                            spinnerUp.setSelection(3)
                            bindingUnit.textInputUnit.text = "cm2"
                        }
                        4 -> {
                            spinnerUp.setSelection(4)
                            bindingUnit.textInputUnit.text = "ft2"
                        }
                        5 -> {
                            spinnerUp.setSelection(5)
                            bindingUnit.textInputUnit.text = "in2"
                        }
                        6 -> {
                            spinnerUp.setSelection(6)
                            bindingUnit.textInputUnit.text = "m2"
                        }
                        7 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit.text = "평"
                        }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
            spinnerDown.adapter = adapterSpinner
            spinnerDown.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    when(position){
                        0 -> {
                            spinnerDown.setSelection(0)
                            bindingUnit.textInputUnit1.text = "ac"
                        }
                        1 -> {
                            spinnerDown.setSelection(1)
                            bindingUnit.textInputUnit1.text = "a"
                        }
                        2 -> {
                            spinnerDown.setSelection(2)
                            bindingUnit.textInputUnit1.text = "ha"
                        }
                        3 -> {
                            spinnerDown.setSelection(3)
                            bindingUnit.textInputUnit1.text = "cm2"
                        }
                        4 -> {
                            spinnerDown.setSelection(4)
                            bindingUnit.textInputUnit1.text = "ft2"
                        }
                        5 -> {
                            spinnerDown.setSelection(5)
                            bindingUnit.textInputUnit1.text = "in2"
                        }
                        6 -> {
                            spinnerDown.setSelection(6)
                            bindingUnit.textInputUnit1.text = "m2"
                        }
                        7 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "평"
                        }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
        }
        bindingUnit.length.setOnClickListener{
            val adapterSpinner = CustomAdapter(this, unit.length)
            spinnerUp.setSelection(5)
            spinnerDown.setSelection(0)
            spinnerUp.adapter = adapterSpinner
            spinnerUp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    when(position){
                        0 -> {
                            spinnerUp.setSelection(0)
                            bindingUnit.textInputUnit1.text = "mm"
                        }
                        1 -> {
                            spinnerUp.setSelection(1)
                            bindingUnit.textInputUnit1.text = "cm"
                        }
                        2 -> {
                            spinnerUp.setSelection(2)
                            bindingUnit.textInputUnit1.text = "m"
                        }
                        3 -> {
                            spinnerUp.setSelection(3)
                            bindingUnit.textInputUnit1.text = "km"
                        }
                        4 -> {
                            spinnerUp.setSelection(4)
                            bindingUnit.textInputUnit1.text = "in"
                        }
                        5 -> {
                            spinnerUp.setSelection(5)
                            bindingUnit.textInputUnit1.text = "ft"
                        }
                        6 -> {
                            spinnerUp.setSelection(6)
                            bindingUnit.textInputUnit1.text = "yd"
                        }
                        7 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit1.text = "mi"
                        }
                        8 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit1.text = "NM"
                        }
                        9 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit1.text = "mil"
                        }
                        10 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit1.text = "자"
                        }
                        11 -> {
                            spinnerUp.setSelection(7)
                            bindingUnit.textInputUnit1.text = "리"
                        }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
            spinnerDown.adapter = adapterSpinner
            spinnerDown.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    when(position){
                        0 -> {
                            spinnerDown.setSelection(0)
                            bindingUnit.textInputUnit1.text = "mm"
                        }
                        1 -> {
                            spinnerDown.setSelection(1)
                            bindingUnit.textInputUnit1.text = "cm"
                        }
                        2 -> {
                            spinnerDown.setSelection(2)
                            bindingUnit.textInputUnit1.text = "m"
                        }
                        3 -> {
                            spinnerDown.setSelection(3)
                            bindingUnit.textInputUnit1.text = "km"
                        }
                        4 -> {
                            spinnerDown.setSelection(4)
                            bindingUnit.textInputUnit1.text = "in"
                        }
                        5 -> {
                            spinnerDown.setSelection(5)
                            bindingUnit.textInputUnit1.text = "ft"
                        }
                        6 -> {
                            spinnerDown.setSelection(6)
                            bindingUnit.textInputUnit1.text = "yd"
                        }
                        7 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "mi"
                        }
                        8 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "NM"
                        }
                        9 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "mil"
                        }
                        10 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "자"
                        }
                        11 -> {
                            spinnerDown.setSelection(7)
                            bindingUnit.textInputUnit1.text = "리"
                        }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }
        }
    }

}