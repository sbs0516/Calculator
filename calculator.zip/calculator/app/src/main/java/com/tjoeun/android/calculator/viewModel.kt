package com.tjoeun.android.calculator

data class ViewModel(val firstName: String, val lastName: String)