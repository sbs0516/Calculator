package com.tjoeun.android.calculator

class TransUnitFunc {

    val areaMapBaseHa = mapOf(Pair("에이커",2.4710538147),Pair("아르",100),Pair("헥타르",1),Pair("제곱센티미터",100000000),
                      Pair("제곱피트",107639.1041671),Pair("제곱인치",15500031.000062),Pair("제곱미터",10000),Pair("평",3025.0001134375))
    val lengthMapBaseNM = mapOf(Pair("밀리미터",1852000),Pair("센티미터",185200),Pair("미터",1852),Pair("킬로미터",1.852),Pair("인치",72913.385826772),
                              Pair("피트",6076.1154855643),Pair("야드",2025.3718285214),Pair("마일",1.150779448),Pair("해리",1),
                              Pair("밀",72913385.826772),Pair("자",6111.6061116061),Pair("리",4.7157407375))
    val tempMapBaseC = mapOf(Pair("섭씨",1),Pair("화씨",33.8),Pair("켈빈",274.15))

    // 영국 갤런, 미국 갤런 구분 필요
    val volumeMapBaseCm3 = mapOf(Pair("영국갤런",219.9692482991),Pair("미국갤런",264.1720523581),Pair("리터",1000),Pair("밀리리터",1000000),Pair("세제곱센티미터",1000000),
                                 Pair("세제곱미터",1),Pair("세제곱인치",61023.744094732),Pair("세제곱피트",35.3146667215),Pair("말",55.4354454238),Pair("되",554.3237250554))

    // 일반 톤, 영국 톤, 미국 톤 구분 필요
    val weightMapBaseT = mapOf(Pair("톤",1.0160469088),Pair("영국톤",1),Pair("미국톤",1.12),Pair("파운드",2240),Pair("온스",35840),
                              Pair("킬로그램",1016.0469088),Pair("그램",1016046.9088),Pair("근",1693.4115146667),Pair("돈",270945.84234667))
    val dataMapBaseTB = mapOf(Pair<String,Long>("비트",8796093022208),Pair("바이트",1099511627776),Pair("킬로바이트",1073741824),Pair("메가바이트",1048576),Pair("기가바이트",1024),Pair("테라바이트",1))
    val speedMapBaseMi = mapOf(Pair("초당미터",1609.344),Pair("시간당미터",5793638.4),Pair("초당킬로미터",1.609344),Pair("시간당킬로미터",5793.6384),Pair("초당인치",63360),
                             Pair("시간당인치",228096000),Pair("초당피트",5280),Pair("시간당피트",19008000),Pair("초당마일",1),Pair("시간당마일",3600),Pair("노트",3128.3144708423))
    val timeBaseWeek = mapOf(Pair("밀리초",604800000),Pair("초",604800),Pair("분",10080),Pair("시간",168),Pair("일",7),Pair("주",1))

    fun transUnitFunc(unitFirst:String, unitSecond:String, transUnit:StringBuffer, map:Map<String,Any>,firstOrSecond:Boolean):StringBuffer{
        val origin = transUnit.toString().toDouble()
        val valueFirst = map[unitFirst].toString().toDouble()
        val valueSecond = map[unitSecond].toString().toDouble()
        val result = StringBuffer("")
        if(firstOrSecond){
            result.append((origin/valueFirst)*valueSecond)
        } else {
            result.append((origin/valueSecond)*valueFirst)
        }
        return result
    }
}